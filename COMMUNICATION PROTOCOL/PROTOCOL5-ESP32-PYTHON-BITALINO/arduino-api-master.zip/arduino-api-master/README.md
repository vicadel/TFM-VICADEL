The BITalino Arduino API documentation is available at http://bitalino.com/docs/arduino-api
